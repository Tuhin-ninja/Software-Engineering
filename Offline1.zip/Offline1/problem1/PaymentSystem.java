package problem1;

public class PaymentSystem implements Payment {
    public String pay(){
        return "Pay your cash and your ticket will be ready!";
    }
}
