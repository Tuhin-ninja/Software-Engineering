package problem1;

public class NFC implements Identification {
    public String identify(){
        return "NFC";
    }
}