package problem1;

public class RaspberryPi implements Microprocessor{
    public String process(){
        return "RaspberryPi";
    }
}
