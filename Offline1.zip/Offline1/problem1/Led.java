package problem1;

public class Led implements Display{
    public String display(){
        return "LED";
    }
}
