package problem1;

public class Ethernet implements Connection{
    public String connect(){
        return "Ethernet";
    }
}
