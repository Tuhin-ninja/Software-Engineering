package problem1;

public class Wifi implements Connection{
    public String connect(){
        return "WiFi";
    }
}
