package problem1;

public class GSM implements Connection{
    public String connect(){
        return "GSM";
    }
}
