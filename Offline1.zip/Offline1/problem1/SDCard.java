package problem1;

public class SDCard implements Storage {
    public String Store(){
        return "SDCard Storage";
    }
}
