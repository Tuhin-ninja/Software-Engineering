package problem1;

public interface Microprocessor {
    String process();
}
