package problem1;

public interface Identification {
    String identify();
}
