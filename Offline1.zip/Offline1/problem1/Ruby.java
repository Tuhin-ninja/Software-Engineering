package problem1;

public class Ruby implements Framework{
    public String useFramework(){
        return "Ruby";
    }
}
