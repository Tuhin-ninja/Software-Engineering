package problem1;

public class RFID implements Identification{
    public String identify(){
        return "RFID";
    }
}
