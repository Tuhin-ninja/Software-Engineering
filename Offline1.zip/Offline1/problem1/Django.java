package problem1;

public class Django implements Framework{
    public String useFramework(){
        return "Django";
    }
}
