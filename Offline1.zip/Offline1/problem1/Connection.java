package problem1;

public interface Connection {
    String connect();
}