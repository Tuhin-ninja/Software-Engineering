package problem1;

public class Lcd implements Display{
    public String display(){
        return "LCD";
    }
}
