package problem1;

public class Node implements Framework{
    public String useFramework(){
        return "NodeJS";
    }
}
