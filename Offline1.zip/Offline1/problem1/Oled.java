package problem1;

public class Oled implements Display{
    public String display(){
        return "OLED"; 
    }
}
