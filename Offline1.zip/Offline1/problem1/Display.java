package problem1;

public interface Display {
    String display();
}
