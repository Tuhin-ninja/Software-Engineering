package problem1;

public class TouchScreenDisplay implements Display {
    public String display(){
        return "TouchScreen Display";
    }
}
