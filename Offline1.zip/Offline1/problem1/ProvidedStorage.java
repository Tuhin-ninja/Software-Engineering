package problem1;

public class ProvidedStorage implements Storage {
    public String Store(){
        return "Provided Storage";
    }
}
