package problem1;

public interface Payment {
    String pay();
}
