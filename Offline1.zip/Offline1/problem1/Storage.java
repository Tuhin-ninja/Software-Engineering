package problem1;

public interface Storage {
    String Store();
} 