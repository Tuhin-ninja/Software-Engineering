package problem1;

public class SeparateController implements Controller{
    public String control(){
        return "Separate Controller"; 
    }
}
