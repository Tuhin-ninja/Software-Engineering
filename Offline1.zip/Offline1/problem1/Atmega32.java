package problem1;

public class Atmega32 implements Microprocessor{
    public String process(){
        return "Atmega32";
    }
}
