package problem1;

public class Arduino implements Microprocessor{
    public String process(){
        return "Arduino";
    } 
}
