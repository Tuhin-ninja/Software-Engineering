package problem1;

public interface Controller {
    String control();
}
