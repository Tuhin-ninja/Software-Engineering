package problem1;

public class TouchScreenController implements Controller{
    public String control(){
        return "TouchScreen Controller"; 
    }
}
