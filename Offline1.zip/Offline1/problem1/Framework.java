package problem1;

public interface Framework {
    String useFramework();
}
