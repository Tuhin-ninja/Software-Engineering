package problem2;

public class RegularAccount extends Account {

    public void setInterest(){
        account_type = "Regular"; 
        account_interest_rate = 2.5; 
    }
}
