package problem2;

public class PremiumLoan extends Loan {
    public void setInterest(){
        loan_type = "Premium"; 
        loan_interest = 12;
    }
}
