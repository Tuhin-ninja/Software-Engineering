package problem2;

public class PremiumAccount extends Account {
    public void setInterest(){
        account_type = "Premium"; 
        account_interest_rate = 3.5; 
    }
}
