package problem2;

public class VIPLoan extends Loan {
    public void setInterest(){
        loan_type = "VIP";
        loan_interest = 10; 
    }
}
