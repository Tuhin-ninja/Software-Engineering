package problem2;

public class VIPAccount extends Account {
    public void setInterest(){
        account_type = "VIP";
        account_interest_rate = 5; 
    }
}
