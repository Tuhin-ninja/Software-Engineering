package problem2;

public class RegularLoan extends Loan {
    public void setInterest(){
        loan_type = "Regular";
        loan_interest = 14; 
    }
}
