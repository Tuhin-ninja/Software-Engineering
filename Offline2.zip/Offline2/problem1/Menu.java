package Offline2.problem1;

public interface Menu {
    public float getPrice();
    public String getName();
} 
